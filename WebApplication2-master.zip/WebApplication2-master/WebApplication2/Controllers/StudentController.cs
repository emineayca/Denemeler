﻿using Microsoft.AspNetCore.Mvc;
using System.Xml.Linq;

namespace WebApplication2.Controllers
{
    public class StudentController : Controller
    {

        // Action Metotları

        public string GetAll()
        {
            return "----tüm öğrenciler----";

        }

        public string GetOneStudent(string name )
        {
            return $"Kayıdını istemiş olduğumuz öğrenci :{name}";// dolarlı süslü parantezli parametre çağırmalı fonksiyon 

        }

        public string Topla(int sayi1, int sayi2 )
        {

            int sonuc =sayi1+sayi2;
            return $"Toplam sonucu :{sonuc.ToString()}";

        }


        public IActionResult Index()
        {
            return View();
        }
    }
}
