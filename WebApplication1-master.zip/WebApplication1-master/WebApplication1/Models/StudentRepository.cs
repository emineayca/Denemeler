﻿namespace WebApplication1.Models
{
    public class StudentRepository : IStudentRepository
    {
    // DB de olmayan InMemory bir kayıtlar oluşturuyorum ve bunları bir liste yapısı halinde tutuyorum 
    public List<Student> DBTable()
        {

            return new List<Student>()
            {

                new Student (){StudentId=1,Name="Ümit KARAÇİVİ", Email="umıt.karacivi@outlook.com",Phone="055527412310",Gender ="E"},

                new Student (){StudentId=2,Name="Ayca Basaran ", Email="basaranaycaaaaaa@hmail.com",Phone="055527412310",Gender ="K"},

                new Student (){StudentId=3,Name="Merve Seker", Email="mervesekerselcuk@gmail.com",Phone="055527412310",Gender ="k"},

                new Student (){StudentId=4,Name="Cekdar Umıt", Email="cekdarumıt@gmail.com ", Phone ="0524412310",Gender ="E"},






            };

    }

    public Student Get(int StudentID)
    {
        return DBTable().FirstOrDefault(e => e.StudentId == StudentID) ?? new Student();// ara bul json formatta yoksa yeni student tanımla // 




    }
    }

}
