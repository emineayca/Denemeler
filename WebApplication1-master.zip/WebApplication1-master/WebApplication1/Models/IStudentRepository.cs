﻿namespace WebApplication1.Models
{
    public interface IStudentRepository
    {
        Student Get(int StudentID);


    }
}
