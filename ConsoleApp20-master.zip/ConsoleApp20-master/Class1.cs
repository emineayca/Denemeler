﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp20
{
    internal class Class1
    {
        
            protected int kareID;
            protected int dikdortgenID;
            protected int cemberID;


        public void setTutorial(int pkr, int pdkdrtgn ,int pcmbr) // 1.form
        {
            kareID = pkr;
            dikdortgenID = pdkdrtgn;
            cemberID = pcmbr;
        }



        public int getutorial
        {
            get { return kareID; }
        }

        public int getDikdortgenID
        {
            get { return dikdortgenID; }
        }

        public int getCemberID
        {
            get { return cemberID; }
        }


    }
