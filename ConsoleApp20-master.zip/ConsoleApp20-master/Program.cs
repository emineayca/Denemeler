﻿using static System.Reflection.Metadata.BlobBuilder;

namespace ConsoleApp20
{
    internal class Program
    {
        struct alanID
        {

            public string cemberalan;
            public string karealan;
            public string dıkdortgenalan;

            
            public static void Main(string[] args)
            {
                alanID cemberalan;  
                alanID karealan;
                alanID dikdortgenalan;

                alanID.cemberalan = π*r²;
                alanID.karealan = kenar1*kenar1;
                alanID.dikdortgenalan = kenar1*kenar2;

                Console.WriteLine("Kare alanı : {0}", kenar1.karealan);
                Console.WriteLine("Dikdörtgen alanı : {0}",alanID .dikdortgenalan);
                Console.WriteLine("Book 2 subject : {0}",);
                

                Console.ReadKey();

            }
}