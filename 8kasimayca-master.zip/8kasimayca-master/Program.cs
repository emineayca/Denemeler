﻿namespace _8kasimayca
{
    internal class Program
    {
        static void Main(string[] args)
        {
           clsSubTutorials altsinif = new clsSubTutorials();
            altsinif.DersAdiBelirle(" .Net Tutorials from Linkedin");// çağırdığım bu metod alt sınıf içinde..
            Console.WriteLine(altsinif.getTutorialName());//alt sınıf üzerinden üst sınıfın  tanımlanmış bir metodunu kullanabiliyorum (kalıtımın nimetleri.aynı mmetodu ekrar kullanmadın 
            Console.ReadKey();
        }
    }
}