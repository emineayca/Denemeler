﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _8kasimayca
{
    internal class clsTutorialsClass1
    {
        protected int TutorialID;//bu tür durumlarda prıotected yapman lazım . public gibi durumlarda 
        protected string TutorialName;

        public void setTutorial(int pID,string pTutorialName)
        {
            TutorialID = pID;
            TutorialName = pTutorialName;
        }
        public string getTutorialName()
        {
            return TutorialName;
        }
    }
}
