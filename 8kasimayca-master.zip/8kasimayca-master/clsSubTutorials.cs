﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _8kasimayca
{
    internal class clsSubTutorials:clsTutorialsClass1 //içine yerleştirmiş oldun 
    {
        // alt sınıf durumunda olan clsSubTutorials da olmayan bir metodu (yani daha önceden yazılmış ama farklı bir sınıfın içinde bulunan kullanabilmek için 
        // :li bir gösterimle bu sınıfıma clsTutorials sınıfımı klonladım.

        public void DersAdiBelirle(string pNewName)
        {
            TutorialName = pNewName;

        }
    }
}
