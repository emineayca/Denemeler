﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _02_AccesModifiars
{
    internal class MoviesClass1
    {
        public string movieName = "The Good,The Bad,The Ugly";

    }
}
