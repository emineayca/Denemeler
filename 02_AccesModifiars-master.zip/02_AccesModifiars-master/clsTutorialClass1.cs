﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _02_AccesModifiars
{
    internal class clsTutorialClass1
    {
        // bu sınıfta bir eğitim seti var .bu eğitimin bir kodu var birde tanımı var 

        int TutorialID;

        string TutorialName;

        //bu değerleri güncelleyecek bir motod yazmak istiyorum 
        //void değer döndürmüyor
         public void setTutorial ( int prmTutorialID, string prmTutorialName )
        {
          TutorialID = prmTutorialID;
          TutorialName = prmTutorialName;




        }

        public string getTutorialName()
        {
            User.user=new User();
           
            return TutorialName;


        }
    }
}
