﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _02_AccesModifiars
{
    internal class kitapClass1
    {

        int BookID;
        string BookName;
        string Author;

    }
     public void setBook(int prmbookID, string prmbookName,string prmAuthor)
    {
        BookID = prmbookID;
        BookName = prmbookName;
        Author = prmAuthor;


    }


    public string getBook()
    {

        string BookDefinition;
        BookDefinition = string.Empty;
        BookDefinition ="Book No :" +BookID.string.ToString()+BookName:+" Author "+Author;



        return BookDefinition;
    }
    int BID;
    string BName;
    string BAuthor;

   Console.WriteLine("Book ID :");
   BID=Convert.ToInt32(Console.ReadLine());

   Console.WriteLine("Book Name :");
   BID=Convert.ToInt32(Console.ReadLine());

   Console.WriteLine("Book Author :");
   BID=Convert.ToInt32(Console.ReadLine());

   clsBook book1=new clsBook();//nesne oluşturuldu
   book1.setBook(BID,BName,BAuthor);


        //birinci kitap bitti

        Console.WriteLine("Book ID :");
   BID=Convert.ToInt32(Console.ReadLine());

   Console.WriteLine("Book Name :");
   BID=Convert.ToInt32(Console.ReadLine());

   Console.WriteLine("Book Author :");
   BID=Convert.ToInt32(Console.ReadLine());

   clsBook book2 = new clsBook();//nesne oluşturuldu
    book1.setBook(BID, BName, BAuthor);


        //2. kitap bitti
        Console.WriteLine("Book ID :");
   BID=Convert.ToInt32(Console.ReadLine());

   Console.WriteLine("Book Name :");
   BID=Convert.ToInt32(Console.ReadLine());

   Console.WriteLine("Book Author :");
   BID=Convert.ToInt32(Console.ReadLine());

   clsBook book3 = new clsBook();//nesne oluşturuldu
    book1.setBook(BID, BName, BAuthor);

        //3. kitap bitti

        //ekrana bastırma kısmı  

        Console.WriteLine(book1.getBook());
        Console.WriteLine(book2.getBook());
        Console.WriteLine(book3.getBook());







}
