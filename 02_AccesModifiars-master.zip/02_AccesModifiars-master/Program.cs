﻿namespace _02_AccesModifiars// namespace bi tane tutar
{
    #region Inline class

    class User
    {
        protected internal string Name;
        protected internal string Location;
        protected internal int Age;

        protected internal void getUserDetails()
        {
            Console.WriteLine($"Name :{Name}");
            Console.WriteLine($"Location :{Location}");
            Console.WriteLine($"Age:{Age}");

        }
    }






    internal class Program
    {
        static void Main(string[] args)
        {
            #region public
            //örneğimizde bir tutorial bilgilerinin bulunacağı bir örnek ve bunu proje için ayrı bir sınıf dosyası içinde tutacağım 

            clsTutorial tutorial =new clsTutorial();
            tutorial.setTutorial(1, "C# Eğitimi ");
            Console.WriteLine(tutorial.getTutorialName);//girmiş olduğum set etmiş olduğum değerleri okuyacağım(get)




            #endregion

            #region private 

            //örneğimizde bir student bilgilerinin bulunacağı bir örnek ve bunu proje için ayrı bir sınıf dosyası içinde tutacağım 
            clsStudentClass1 student = new clsStudentClass1();
            Console.WriteLine("Name :" + student.Name);
            student.getName();

            #endregion
            #region Inline
            User user = new User();
            user.Name = "ÜK";
            user.Location = "Estonia";
            user.Age = 58;
            user.getUserDetails();
            Console.WriteLine("lütfen bir tuşa basınız ...");

            #endregion
            #region protected 
            clsMovies movies= new clsMovies ();
            Console.WriteLine("Movies Name: {0}", movies.movieName);
            #endregion
            #region Another sample
            // bir bookstoremumuz var .burada kitapların nosu adı yazarı tutulacaktır.ve ekrandan giriş alınarak sanki bir bookdb oluşturulacaktır. ve istendiği zaman kitap listesi öğrenilebilecektir


            #endregion
            Console.ReadKey();

        }
    }
}