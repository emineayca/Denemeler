﻿namespace encaplation9kasim
{
    internal class Program
    {
        static void Main(string[] args)
        {
            #region normal durum
            
            clsBank=new clsBank();

            bank.AccountNumber = 1234567890123;

            bank.Name = "Santander bank";

            bank.Balance = 500;// elden yatırdım
            
            
            bank.getBalance();
            bank.setBalance(1000); //biryereden geldi
            bank.getBalance();

            #endregion

            #region get/set olayı 

            clsBank bankgs = new clsBank();

            bankgs.setBalanceCaps(500);// set ediyorum 

            Console.WriteLine($" hesabınızdaki miktar:{bankgs.getBalanceCaps()} EURO dur ....");// get ediyorum 

            #endregion

            #region // eğer sınıfı tasarlarken kapsülleme uymazsak ne olur 

            //açıklamalar gelecek 
             clsBank bank2= new clsBank();

            bank2.Balance(1000); 

            Console.WriteLine($"Bankadaki miktarınız {bank2.Balance} PNG Kina dır..\n\n");

            bank2.Balance = -5000;

            Console.WriteLine($"Bankadaki miktarınız {bank2.Balance} PNG Kina dır..\n\n");
            // yukarda negatif değer girdiği için hata 

            try
            {
                int deger;
                clsBank bank3 = new clsBank();

                Console.WriteLine(" Lütfen miktarı giriniz :");
                deger = Convert.ToInt32(Console.ReadLine());
                bank3.setBalanceCaps(deger);
                Console.WriteLine($"\n\n düzgün durur \n\n  Bankanızdaki miktar :{bank3.getAmount ()}PNG Kinadır");

                Console.WriteLine("lütfen yeni miktarı giriniz :");
                deger = Convert.ToInt32(Console.ReadLine());
                bank3.setAmount(deger);

                bank3.SetAmount();// harflrin setin s si büyük küçük farkeder
                Console.WriteLine($"\n\n düzgün durur \n\n  Bankanızdaki miktar :{bank3.GetAmount()}PNG Kinadır\");
            }
            catch (Exception hata )
            {

                Console.WriteLine(hata.Message);
            }

            // get/set olayı değişkenler /property lere uygulanabilir ..işte bu durumda get/set keywordlarını kulllanabilirim 

            try
            {
                clsBank bank4 = new clsBank();
                bank4.Amount1 = 1000;// hemen geri plnada otomatik set calıştırır

                Console.WriteLine("miktar:{0}",bank4.Amount1);// get motodu girdi devreye

                bank4.Amount1 = -5000;
                Console.WriteLine("miktar :{0}/n/n"bank4.Amount1);
            }

            catch (Exception hata)
            {
                Console.WriteLine(hata.Message);
            }


            try
            {

            clsBank bank5= new clsBank();
                bank5._Amount = 1000;
                Console.WriteLine($"miktar :{bank5.Amount2}"); //direk değişkenin kendisiner uşlatın bu metodda

                bank5._Amount2 = -1000;
                Console.WriteLine($"miktar :{bank5.Amount2}");
            }

            catch (Exception)
            {
                Console.WriteLine(" lütfen pozitif sayı girin ..");

            }
        }
    }