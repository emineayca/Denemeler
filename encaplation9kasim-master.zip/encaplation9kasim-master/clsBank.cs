﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Security;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace encaplation9kasim
{
    internal class clsBank
    {
        #region Normal durum 
        public long AccountNumber;// hesap no
        public string Name;
        public int Balance;//miktar

        public void getBalance() // miktarı öğrenmek 
        {

            Console.WriteLine("hesaptaki miktar :{0} eurodur ", this.Balance);
         
        }

        public void setBalance(int balance)
        {
            this.Balance = this.Balance+ Balance;
        }
        #endregion

        #region getter ve setter 
        private double balance; // b si küçük balance bu farkli.yani dışarıya kapalı bir değişkenn tanımı yapılmış 
        // setter -getter metodlarının tanımlanması 

        //public bir şekilde tanımlanan getter(get) metodu 

        // bu metod aslında balance değişkeninde tutulan değeri öğrenmek  için 

        public double getBalanceCaps()
        {
            // diyelim burda bi kodlar var ..

            return balance;

        }

        //public bir şekilde tanımlanan getter(get) metodu 

        // bu metod aslında balance değişkeninin içeriğini güncelleme için 

        public void setBalanceCaps(double balance)
        {
            //diyelim burda kodlar var
            this.balance = balance;//o an oluşan balance değerini bu sınıf içerisindeki değişkene yerleştir ()this keyword ile 
        }

        public int Amount;


        public int  getAmount()
        {

            return Amount;

        }

        public void setAmount(int amount)//kendi set metodum
        {
            if(amount < 0)
            {
                this.Amount = amount;
            }

            else// throw hatayı fırlatır geri döndürür.
            {

                throw new Exception("lütfen düzgün sayıyı gir..");
            }
        }
         catch (Exception hata )
            {

                Console.WriteLine(hata.Message);
            }

            // get/set olayı değişkenler /property lere uygulanabilir ..işte bu durumda get/set keywordlarını kulllanabilirim 

            try
            {
                clsBank bank4 = new clsBank();

}
          #region

          private int _Amount1
{




               get // veri almak için get 
                {
                     return _Amount1;
               }
              set //içini doldurmak için set
                {
        if (value < 0)
        {
            throw new Exception("lütfen girdiğiniz miktara dikkat ediniz ..pozitif gir ");//yen
        }
        else
        {


            _Amount1 = value;// value değer olarak ne üdğü belirisiz an 
        }

        
        }

    public int _Amount2 { get;set; }// daha kısa bir yöntem 




    }
}

           //get/set kullanımı eski yöntemi

             

        #endregion
    }
}
