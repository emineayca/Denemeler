﻿namespace ConsoleApp14
{
    internal class Program
    {
       public static void Main(string[] args)
        {
            //Console.Clear();//ekranı temizler
            //#region Abs // mutlak değer hesapladı 
            ////abs metot maths clasın içinde 
            //int sayi1 = -1000;
            //int sayi2 = 5;

            //int abs1=Math.Abs(sayi1);
            //int abs2=Math.Abs(sayi2);

            //Console.WriteLine(" Sayım :{0} - ABS si{1} ", sayi1, abs1);

            //Console.WriteLine(" Sayım :{0} - ABS si{1} ", sayi2, abs2);

            //Console.WriteLine();





            #endregion

            #region  max,min 

            int sayi1 = 37;
            int sayi2 = 100;
            //min max sadece iki sayıya duyarlı 
            int sonucmin=Math.Min(sayi1, sayi2);
            int sonucmax=Math.Max(sayi1,sayi2);
            Console.WriteLine("küçük sayı :{0}- büyük sayı {1}", sonucmin, sonucmax);


# endregin
            #region pow
            double sayi1 = 4;
            double sayi 5;
            double sonuc =Math.Pow(sayi1, sayi2);
            Console.WriteLine("sonuc :{0}", sonuc);

            #endregion
            #region round en yakına yuvarlıyor .3 49 da sa 3 e . 3,51 se 4 e 

            double sonuc = Math.Pow(0, 5);
            Console.WriteLine("sonuc ={0} ", sonuc);

            #region
            //ceiling virgülden sonra herhangi bir ondalık varsa yukarı yuvarlar3.1 i 4 e yuvarlar .tavana yuvarlar

            Console.WriteLine("sonuc :{0}", Math.Ceiling(2.2));
              Console.WriteLine("sonuc :{0}", Math.Ceiling(3.0));

            //floor virgülden sonra tabana yuvarlar .
            double sayi = Math.Floor(8.99);
            Console.WriteLine("sonuc{0}", Math.Floor(3.01));
            Console.WriteLine("sonuc {0}", Math.Floor(3, 99));

                #endregion 





        }
    }